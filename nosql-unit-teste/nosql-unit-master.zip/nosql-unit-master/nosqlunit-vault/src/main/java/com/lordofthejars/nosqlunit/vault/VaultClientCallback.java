package com.lordofthejars.nosqlunit.vault;

import com.bettercloud.vault.VaultConfig;

public interface VaultClientCallback {

    VaultConfig vaultConfiguration();

}
