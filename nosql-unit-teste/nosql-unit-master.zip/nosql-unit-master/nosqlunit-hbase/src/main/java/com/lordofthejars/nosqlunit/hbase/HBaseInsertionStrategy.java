package com.lordofthejars.nosqlunit.hbase;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface HBaseInsertionStrategy extends InsertionStrategy<HBaseConnectionCallback> {

}
