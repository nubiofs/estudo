package com.lordofthejars.nosqlunit.hbase;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface HBaseComparisonStrategy extends ComparisonStrategy<HBaseConnectionCallback> {

}
