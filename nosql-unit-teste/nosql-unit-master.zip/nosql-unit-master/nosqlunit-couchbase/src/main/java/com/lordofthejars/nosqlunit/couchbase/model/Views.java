package com.lordofthejars.nosqlunit.couchbase.model;

public class Views {

}
