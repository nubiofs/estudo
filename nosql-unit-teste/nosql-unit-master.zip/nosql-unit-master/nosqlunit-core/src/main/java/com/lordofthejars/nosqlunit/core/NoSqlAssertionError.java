package com.lordofthejars.nosqlunit.core;

public class NoSqlAssertionError extends AssertionError {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3545626870713648771L;

	public NoSqlAssertionError(String message) {
		super(message);
	}
	
}
