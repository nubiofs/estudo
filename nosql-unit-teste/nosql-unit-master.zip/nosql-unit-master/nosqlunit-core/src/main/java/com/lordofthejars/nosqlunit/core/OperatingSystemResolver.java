package com.lordofthejars.nosqlunit.core;

public interface OperatingSystemResolver {

	OperatingSystem currentOperatingSystem();
	
}
