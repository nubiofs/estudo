package com.lordofthejars.nosqlunit.objects;

public class KeyValueTokens {

	public static final String VALUE_TOKEN = "value";
	public static final String IMPLEMENTATION_TOKEN = "implementation";
	public static final String IMPLEMENTATION_KEY_TOKEN = "implementationKey";
	public static final String KEY_TOKEN = "key";
	public static final String DATA_TOKEN = "data";
	
}
