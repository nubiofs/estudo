package com.lordofthejars.nosqlunit.core;

public interface Configuration {

}
