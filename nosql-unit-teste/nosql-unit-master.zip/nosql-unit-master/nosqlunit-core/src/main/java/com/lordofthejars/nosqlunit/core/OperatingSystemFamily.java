package com.lordofthejars.nosqlunit.core;

public enum OperatingSystemFamily {
    LINUX,
    WINDOWS,
    UNIX,
    DEC_OS,
    MAC,
    UNKNOWN;
}
