package com.lordofthejars.nosqlunit.core;

public interface LifecycleManager {

	void startEngine() throws Throwable;
	void stopEngine() throws Throwable; 
	
}
