package com.lordofthejars.nosqlunit.couchdb;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface CouchDbInsertionStrategy extends InsertionStrategy<CouchDbConnectionCallback> {

}
