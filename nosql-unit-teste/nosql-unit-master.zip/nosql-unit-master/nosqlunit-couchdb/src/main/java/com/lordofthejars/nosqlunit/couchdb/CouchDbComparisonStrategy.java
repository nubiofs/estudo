package com.lordofthejars.nosqlunit.couchdb;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface CouchDbComparisonStrategy extends ComparisonStrategy<CouchDbConnectionCallback> {

}
