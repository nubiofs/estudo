package com.lordofthejars.nosqlunit.elasticsearch;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface ElasticsearchComparisonStrategy extends ComparisonStrategy<ElasticsearchConnectionCallback> {

}
