package com.lordofthejars.nosqlunit.elasticsearch2;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface ElasticsearchInsertionStrategy extends InsertionStrategy<ElasticsearchConnectionCallback> {
}
