package com.lordofthejars.nosqlunit.elasticsearch2;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface ElasticsearchComparisonStrategy extends ComparisonStrategy<ElasticsearchConnectionCallback> {
}
