package com.lordofthejars.nosqlunit.cassandra;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface CassandraComparisonStrategy extends ComparisonStrategy<CassandraConnectionCallback> {

}
