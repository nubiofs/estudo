package com.lordofthejars.nosqlunit.redis;


public class ShardedRedisConfiguration extends AbstractRedisConfiguration {

}
