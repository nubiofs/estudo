package com.lordofthejars.nosqlunit.redis;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface RedisComparisonStrategy extends ComparisonStrategy<RedisConnectionCallback> {

}
