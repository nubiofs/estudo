package com.lordofthejars.nosqlunit.redis;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface RedisInsertionStrategy extends InsertionStrategy<RedisConnectionCallback> {

}
