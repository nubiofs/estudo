package com.lordofthejars.nosqlunit.mongodb;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface MongoInsertionStrategy extends InsertionStrategy<MongoDbConnectionCallback> {
}
