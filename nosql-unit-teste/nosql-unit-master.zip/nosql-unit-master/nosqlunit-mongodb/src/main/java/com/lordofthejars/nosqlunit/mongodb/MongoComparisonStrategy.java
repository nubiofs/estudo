package com.lordofthejars.nosqlunit.mongodb;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface MongoComparisonStrategy extends ComparisonStrategy<MongoDbConnectionCallback> {

}
