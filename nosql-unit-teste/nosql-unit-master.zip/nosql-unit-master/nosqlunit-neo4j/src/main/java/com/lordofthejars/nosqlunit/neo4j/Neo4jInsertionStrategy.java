package com.lordofthejars.nosqlunit.neo4j;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface Neo4jInsertionStrategy extends InsertionStrategy<Neo4jConnectionCallback> {

}
