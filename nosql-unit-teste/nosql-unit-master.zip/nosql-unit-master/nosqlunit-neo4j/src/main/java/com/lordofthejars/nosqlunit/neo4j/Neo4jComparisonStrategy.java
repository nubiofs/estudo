package com.lordofthejars.nosqlunit.neo4j;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface Neo4jComparisonStrategy extends ComparisonStrategy<Neo4jConnectionCallback> {

}
