package com.lordofthejars.nosqlunit.infinispan;

import com.lordofthejars.nosqlunit.core.InsertionStrategy;

public interface InfinispanInsertionStrategy extends InsertionStrategy<InfinispanConnectionCallback> {

}
