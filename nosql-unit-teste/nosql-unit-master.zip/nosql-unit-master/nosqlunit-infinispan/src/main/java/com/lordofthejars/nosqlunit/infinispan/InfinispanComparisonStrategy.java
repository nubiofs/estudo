package com.lordofthejars.nosqlunit.infinispan;

import com.lordofthejars.nosqlunit.core.ComparisonStrategy;

public interface InfinispanComparisonStrategy extends ComparisonStrategy<InfinispanConnectionCallback> {

}
