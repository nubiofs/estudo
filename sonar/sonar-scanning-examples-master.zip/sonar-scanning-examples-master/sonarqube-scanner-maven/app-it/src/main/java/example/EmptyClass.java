package example;

public class EmptyClass {

}
