# Pandas-Merge-Tutorial

A tutorial on merging and joining data frames using Python Pandas. 

See accommpanying blog post at http://www.shanelynn.ie/merge-join-dataframes-python-pandas-index-1/
