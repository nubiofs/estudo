# Topics/Outline

Terminology issues

SLiM as a starting point

- ignore cluster
- model every cluster
- Why these aren't the best option

Visual starting point

- spaghetti plot

Random intercepts

- issues in interpretation
- prediction (conditional vs. not)

Random slopes

- additional interpretation
- compare to results from modeling every cluster
- prediction visualization

Simulation demo

Other Complexities

- Additional clustering, nested or otherwise
- Residual correlation
- glmm, stars
- Bayesian

Alternative approaches

- fixed effects, gee, sem


Exercises