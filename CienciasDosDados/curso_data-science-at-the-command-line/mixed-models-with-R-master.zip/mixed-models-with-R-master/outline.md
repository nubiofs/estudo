Outline


Intro

- Overview
- Terminology
- Data setup

Standard clustering

- Random Intercepts demo
- Data: Popularity

Longitudinal Data

- Random Slopes demo
- Group level covariates
- Data: sleep study (lme4)


Nested/Multilevel struture

- Data: 

Issues

- Alternative approaches
- Number of groups
- Number of observations within groups
- crossed and nested

Other

- brief prelude to growth curves

Exercises