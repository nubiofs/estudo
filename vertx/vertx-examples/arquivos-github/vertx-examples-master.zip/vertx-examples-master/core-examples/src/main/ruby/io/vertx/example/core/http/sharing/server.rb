$vertx.deploy_verticle("io.vertx.example.core.http.sharing.HttpServerVerticle", {
  'instances' => 2
})
