package com.github.mtatheonly.plugins.quasar

class QuasarInstrumentationPluginExtension {
    boolean instrumentorCheck = false
    boolean instrumentorVerbose = false
    boolean instrumentorDebug = false
    boolean instrumentorAllowMonitors = false
    boolean instrumentorAllowBlocking = false
}