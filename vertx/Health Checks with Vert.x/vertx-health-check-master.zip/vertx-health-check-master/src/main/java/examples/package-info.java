/**
 * @author <a href="http://escoffier.me">Clement Escoffier</a>
 */
@Source
package examples;

import io.vertx.docgen.Source;
