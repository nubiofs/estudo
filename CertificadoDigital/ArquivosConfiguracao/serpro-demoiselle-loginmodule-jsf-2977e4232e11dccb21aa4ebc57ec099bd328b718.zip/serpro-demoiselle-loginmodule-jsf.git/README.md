# SERPRO Demoiselle-Loginmodule-JSF

Facilita a utilização do componente Serpro Login Module por aplicações desenvolvidas com Demoiselle, e utilizam JSF.

**Conteúdo**

1. [Premissas](#1-premmissas)
2. [Criando o projeto](#2-criando-o-projeto)
3. [Configuração](#3-configura-o)
	1. [Repositório](#3-1-reposit-rio)
	2. [Dependências](#3-2-depend-ncias)
	3. [JBoss Deployment Structure](#3-3-jboss-deployment-structure)
4. [Autenticação](#4-autenticacao)
	1. [JAAS](#4-1-jaas)
	2. [SERPRO Principal](#4-2-serpro-principal)

## 1. Premissas

Este componente foi desenvolvido presumindo que a aplicação utilizará o JBoss EAP. Entretanto, caso você opte por uma configuração diferente, basta adaptar o passo-a-passo deste documento para as tecnologias que desejar.

## 2. Criando o projeto

No Eclipse acesse: `File / New / Other.. / Maven Project`

Crie o projeto utilizando a versão mais recente do arquétipo `demoiselle-jsf-jpa` disponível no catálogo [Maven Central](https://repo1.maven.org/maven2/archetype-catalog.xml) que já vem pré-configurado no [Eclipse Luna](https://www.eclipse.org/luna/).

## 3. Configuração

### 3.1 Repositório

Adicione os seguintes repositórios ao `pom.xml` da sua aplicação:

```xml
<repositories>
	<!-- Artefatos do SERPRO já liberados -->
	<repository>
		<id>serpro-nexus-componentes-corporativos</id>
		<url>http://nexus.aic.serpro/content/repositories/componentes-corporativos</url>
		<snapshots>
			<enabled>false</enabled>
		</snapshots>
		<releases>
			<enabled>true</enabled>
		</releases>
	</repository>

	<!-- Artefatos do SERPRO em fase de desenvolvimento (opcional) -->
	<repository>
		<id>serpro-nexus-snapshots</id>
		<url>http://nexus.aic.serpro/content/repositories/snapshots</url>
		<snapshots>
			<enabled>true</enabled>
		</snapshots>
		<releases>
			<enabled>false</enabled>
		</releases>
	</repository>
</repositories>
```

### 3.2 Dependências

Adicione as seguintes dependências ao `pom.xml` da sua aplicação:

```xml
<dependencyManagement>
	<!-- Predefinições das versões dos módulos do JBoss EAP -->
	<dependencies>
		<dependency>
			<groupId>org.jboss.as</groupId>
			<artifactId>jboss-as-parent</artifactId>
			<version>7.2.0.Final</version>
			<type>pom</type>
			<scope>import</scope>
		</dependency>
	</dependencies>
</dependencyManagement>
	
<dependencies>
	<!-- SERPRO Demoiselle-Loginmodule-JSF -->
	<dependency>
		<groupId>br.gov.serpro</groupId>
		<artifactId>serpro-demoiselle-loginmodule-jsf</artifactId>
		<version>1.0.0</version>
		<scope>compile</scope>
	</dependency>
	
	<!-- SERPRO Javax-API (opcional): autenticação SERPRO Principal e Certificado Digital ICP-Brasil -->
	<dependency>
		<groupId>br.gov.serpro</groupId>
		<artifactId>serpro-javax-api</artifactId>
		<version>1.0.0</version>
		<scope>provided</scope>
	</dependency>
</dependencies>
```

### 3.3 JBoss Deployment Structure

Crie o arquivo `src/main/webapp/WEB-INF/jboss-deployment-structure.xml` com o seguinte conteúdo:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<jboss-deployment-structure xmlns="urn:jboss:deployment-structure:1.1">

	<deployment>
		<dependencies>
			<!-- SERPRO Javax-API (opcional): autenticação SERPRO Principal e Certificado Digital ICP-Brasil -->
			<module name="br.gov.serpro.javax.api" />
		</dependencies>
	</deployment>

</jboss-deployment-structure>
```

## 4. Autenticação

### 4.1. JAAS

Esse componente facilita a integração com o componente [serpro-loginmodule](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master), que permite à sua aplicação autenticar com Certificado Digital da ICP-Brasil, com o LDAP, e (futuramente) com outros meios de autenticação do SERPRO (como o Senha Rede).
 
Após configurar o módulo JAAS disponível no compoenente [serpro-loginmodule](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master) no standalone.xml do JBoss EAP, indique no `demoiselle.properties` o nome do Security Domain:

 ```
 br.gov.serpro.auth.loginmodule=meu_modulo_jaas
  ```

Caso nenhum módulo seja informado, o componente buscará pelo módulo `other`.

Além disso, também no `demoiselle.properties` você deve configurar a classe que será utilizada para a autenticação, que nesse caso será a classe `SerproAuthenticator` do componente [serpro-loginmodule](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master):

 ```
frameworkdemoiselle.security.authenticator.class=br.gov.serpro.auth.SerproAuthenticator
  ```

Para proceder com a autenticação basta a aplicação invocar o método `securityContext.login()` passando usuário e senha na submissão, ou, para autenticar com certificado digital, invocar o método `certificateAuthJSF.login()`, como mostra o projeto de exemplo [serpro-loginmodule-exemplo-jsf](http://gitlab.serpro/demoiselle/serpro-loginmodule-exemplo-jsf/tree/master).

### 4.2 SERPRO Principal

É possível utilizar qualquer LoginModule JAAS, entretanto, utilizando o [serpro-loginmodule](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master) você terá acesso a um Principal recheado de informações, o `SerproPrincipal`.

Para ter acesso ao SerproPrincipal basta obter normalmente o usuário logado e fazer o _Type Casting_:

 ```java
SerproPrincipal principal = (SerproPrincipal) Beans.getReference(SecurityContext.class).getUser();
  ```

