/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth;

import static br.gov.frameworkdemoiselle.annotation.Priority.L4_PRIORITY;

import java.security.AccessController;
import java.security.Principal;
import java.security.PrivilegedExceptionAction;

import javax.enterprise.context.SessionScoped;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import br.gov.frameworkdemoiselle.annotation.Priority;
import br.gov.frameworkdemoiselle.security.InvalidCredentialsException;
import br.gov.frameworkdemoiselle.security.Authenticator;
import br.gov.frameworkdemoiselle.util.Beans;

@SessionScoped
@Priority(L4_PRIORITY)
public class SerproAuthenticator implements Authenticator {

	private static final long serialVersionUID = 1L;

	private JAASConfig config = null;
	private LoginContext loginContext = null;
	
	@Override
	public void authenticate() throws Exception {

		config = Beans.getReference(JAASConfig.class);
		loginContext = createLoginContext(config.getLoginModule());
		
		try {
			loginContext.login();
		} catch (LoginException cause) {
			throw new InvalidCredentialsException(cause.getMessage(), cause);
		}
	}

	public LoginContext createLoginContext(final String module) throws Exception {
		return AccessController.doPrivileged(new PrivilegedExceptionAction<LoginContext>() {

			public LoginContext run() throws LoginException {
				return new LoginContext(module, new Subject(), new SerproCallbackHandler());
			}
		});
	}
	
	@Override
	public void unauthenticate() throws Exception {
		this.loginContext.logout();
	}

	@Override
	public Principal getUser() {
		if(this.loginContext != null){
			return loginContext.getSubject().getPrincipals().iterator().next();
		}
		
		return null;
	}
}
