/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth;

import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import br.gov.frameworkdemoiselle.security.SecurityContext;
import br.gov.frameworkdemoiselle.util.Beans;
import br.gov.serpro.auth.SerproCallbackHandler.Certificates;

@Named("certificateAuthJSF")
public class CertificateAuthJSF {
	
	private static final Logger logger = Logger.getLogger(CertificateAuthJSF.class.getName());

	@Inject
	private HttpServletRequest request;

	public void login() {
		X509Certificate[] x509Certificates = null;

		if ((x509Certificates = getCertificates(request)) != null) {
			Certificates certificates = Beans.getReference(Certificates.class);
			setCertificates(x509Certificates, certificates);
			setChain(x509Certificates, certificates);

			SecurityContext securityContext = Beans.getReference(SecurityContext.class);
			securityContext.login();
			boolean loggedIn = securityContext.isLoggedIn();

			if (loggedIn) {
				logger.log(Level.parse("DEBUG"), "Logado com certificado digital");
			}
		}
	}

	private X509Certificate[] getCertificates(ServletRequest request) {
		final String X509_CERTIFICATE = "javax.servlet.request.X509Certificate";
		return (X509Certificate[]) request.getAttribute(X509_CERTIFICATE);
	}

	private void setCertificates(X509Certificate[] x509Certificates, Certificates certificates) {
		if (x509Certificates.length > 0) {
			certificates.setCertificate(x509Certificates[0]);
		}
	}

	private void setChain(X509Certificate[] x509Certificates, Certificates certificates) {
		final int length = x509Certificates.length;

		if (length > 1) {
			X509Certificate[] chain = new X509Certificate[length - 1];

			for (int i = 1; i < length - 1; i++) {
				chain[i] = x509Certificates[i];
			}

			certificates.setChain(chain);
		}
	}
}
