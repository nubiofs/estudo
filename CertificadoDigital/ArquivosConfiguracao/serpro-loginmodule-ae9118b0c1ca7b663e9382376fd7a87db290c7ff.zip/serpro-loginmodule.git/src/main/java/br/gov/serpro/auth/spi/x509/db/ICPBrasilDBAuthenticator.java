/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth.spi.x509.db;

import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.login.LoginException;
import javax.sql.DataSource;

import org.apache.commons.lang.SerializationUtils;
import org.jboss.security.PicketBoxMessages;

import br.gov.serpro.auth.spi.Util;
import br.gov.serpro.auth.spi.x509.ICPBrasilAuthenticator;
import br.gov.serpro.auth.spi.x509.ICPBrasilUtil;

public class ICPBrasilDBAuthenticator extends ICPBrasilAuthenticator {

	private Util util;

	private String dsJndiName;
	private String principalQuery;
	
	private static final String DS_JNDI_NAME = "cert.db.dsJndiName";
	private static final String PRINCIPALS_QUERY = "cert.db.principalQuery";

	@Override
	public void initialize(Map<String, ?> options, Util util) {
		super.initialize(options, util);
		this.util = util;
		loadOptions(options);
	}

	@Override
	public String getAlias() {
		return "CERT-DB";
	}

	@Override
	public byte[] authenticate() throws Exception {

		byte[] retorno = super.authenticate();

		//teste+
		/*
		authenticateDB(SerializationUtils.deserialize(retorno));
		
		return retorno;
		*/
		return null;
		//teste-
		

	}

	private void authenticateDB(Object id) throws Exception {
	
		if (this.dsJndiName == null || this.principalQuery == null) {
			throw new LoginException("As propriedades cert.db.dsJndiName e cert.db.principalQuery não podem ser nulas");
		}
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;

		try {

			InitialContext ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup(this.dsJndiName);
			conn = ds.getConnection();
			ps = conn.prepareStatement(this.principalQuery);

			String cpf = (id instanceof X509Certificate) ? 
					ICPBrasilUtil.getCpfFromCertificate((X509Certificate) id) : (String) id;
			
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			
			if (rs.next() && Long.valueOf(rs.getString(1)).equals(0L)) {
				//return false;
				throw new LoginException("Usuário não autenticado no banco de dados");
			}

		} catch (NamingException ex) {
			LoginException le = new LoginException(
					PicketBoxMessages.MESSAGES.failedToLookupDataSourceMessage(this.dsJndiName));
			le.initCause(ex);
			throw le;
		} catch (SQLException ex) {
			LoginException le = new LoginException(PicketBoxMessages.MESSAGES.failedToProcessQueryMessage());
			le.initCause(ex);
			throw le;
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException ex) {
				}
			}

		}

	}
	
	private void loadOptions(Map<String, ?> options) {
		this.dsJndiName = util.getOption(DS_JNDI_NAME, String.class, null, options);
		this.principalQuery = util.getOption(PRINCIPALS_QUERY, String.class, null, options);
	}

	@Override
	public String getLoginFailedMessage() {
		return "usuário invalido no banco";
	}

	@Override
	public void close() {
	}

}
