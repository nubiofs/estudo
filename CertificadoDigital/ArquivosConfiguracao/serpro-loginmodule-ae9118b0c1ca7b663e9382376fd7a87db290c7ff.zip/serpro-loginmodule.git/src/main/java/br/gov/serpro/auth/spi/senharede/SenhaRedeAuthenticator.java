/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth.spi.senharede;

import java.util.Map;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;

import org.apache.commons.lang.SerializationUtils;

import br.gov.serpro.auth.spi.Authenticator;
import br.gov.serpro.auth.spi.Util;

public class SenhaRedeAuthenticator implements Authenticator {

	private SenhaRedeProxy proxy;

	private NameCallback nameCallback;

	private PasswordCallback passwordCallback;
	
	@Override
	public String getAlias() {
		return "SENHAREDE";
	}

	@Override
	public void initialize(Map<String, ?> options, Util util) throws Exception {
		this.nameCallback = new NameCallback("Login :");
		this.passwordCallback = new PasswordCallback("Senha :", false);
		this.proxy = new SenhaRedeProxy(options, util);
	}

	@Override
	public Callback[] getCallBacks() {
		return new Callback[] { nameCallback, passwordCallback };
	}

	@Override
	public boolean isSupported() {
		return nameCallback.getName() != null && !nameCallback.getName().isEmpty();
	}

	@Override
	public byte[] authenticate() throws Exception {
		String username = nameCallback.getName();
		String password = new String(passwordCallback.getPassword());

		proxy.authenticate(username, password);

		return SerializationUtils.serialize(username);
	}

	@Override
	public String getLoginFailedMessage() {
		return proxy.getExceptionMessage();
	}

	@Override
	public void close() {
		this.proxy.close();
	}

}
