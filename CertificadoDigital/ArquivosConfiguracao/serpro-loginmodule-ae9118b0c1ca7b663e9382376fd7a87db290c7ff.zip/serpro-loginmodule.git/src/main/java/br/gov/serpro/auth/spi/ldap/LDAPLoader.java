/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth.spi.ldap;

import java.security.cert.X509Certificate;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;

import org.apache.commons.lang.SerializationUtils;

import br.gov.serpro.auth.SerproPrincipal.UserPrincipalBuilder;
import br.gov.serpro.auth.spi.Loader;
import br.gov.serpro.auth.spi.Util;
import br.gov.serpro.auth.spi.x509.ICPBrasilUtil;

public class LDAPLoader implements Loader {

	private Util util;

	private UserPrincipalBuilder builder;

	private LDAPProxy proxy;

	@Override
	public void initialize(Map<String, ?> options, UserPrincipalBuilder builder, Util util) throws Exception {
		this.util = util;
		this.builder = builder;
		this.proxy = new LDAPProxy(options, util);
	}

	@Override
	public String getAlias() {
		return "LDAP";
	}

	@Override
	public boolean load(byte[] userAuthenticated) throws Exception {
		String cpf;
		Object id = SerializationUtils.deserialize(userAuthenticated);
		
		cpf = (id instanceof X509Certificate) ? 
				ICPBrasilUtil.getCpfFromCertificate((X509Certificate) id) : (String) id;
		
		proxy.authenticate();
		String dn = proxy.getDN(cpf);

		boolean loaded = false;
		Attributes attributes = proxy.getAttributes(dn);

		if (attributes != null) {
			Attribute attribute;

			attribute = attributes.get("employeeNumber");
			loaded |= attribute != null;
			builder.enrollment(attribute != null ? attribute.get().toString() : null);

			attribute = attributes.get("givenName");
			loaded |= attribute != null;
			builder.name(attribute != null ? attribute.get().toString() : null);

			attribute = attributes.get("mail");
			loaded |= attribute != null;
			builder.email(attribute != null ? attribute.get().toString() : null);

			attribute = attributes.get("cn");
			loaded |= attribute != null;
			builder.fullName(attribute != null ? attribute.get().toString() : null);

			attribute = attributes.get("telephoneNumber");
			loaded |= attribute != null;
			builder.telephoneNumber(attribute != null ? attribute.get().toString() : null);

			attribute = attributes.get("ou");
			loaded |= attribute != null;
			builder.department(attribute != null ? attribute.get().toString() : null);

		} else {
			loaded = false;
		}

		if (loaded) {
			this.util.log("usuário " + cpf + " carregado com sucesso");
		} else {
			this.util.log("usuário " + cpf + " não foi carregado: verifique as permissões da conexão");
		}

		return loaded;
	}

	@Override
	public void close() {
		try {
			this.proxy.close();
		} catch (NamingException cause) {
			this.util.log(cause);
		}
	}
}
