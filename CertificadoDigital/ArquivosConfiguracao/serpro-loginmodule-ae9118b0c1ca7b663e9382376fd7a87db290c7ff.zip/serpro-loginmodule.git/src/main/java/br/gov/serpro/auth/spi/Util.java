/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth.spi;

import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Util {

	private Logger logger;

	private boolean debug;

	public Util(Logger logger) {
		this.logger = logger;
	}

	public void setDebug(boolean debug) {
		this.debug = debug;
	}

	@SuppressWarnings("unchecked")
	public <T> T getOption(String key, Class<T> target, T defaultValue, Map<String, ?> options) {
		T result = null;

		if (options.containsKey(key)) {
			String value = (String) options.get(key);

			if (target == String.class) {
				result = (T) value;

			} else if (target == Boolean.class) {
				result = (T) Boolean.valueOf(value);
			}

		} else {
			result = defaultValue;
		}

		log("carregando atributo " + key + "=" + result + (result == defaultValue ? " (default)" : ""));

		return result;
	}

	public void log(String message) {
		if (this.debug) {
			logger.log(Level.parse("DEBUG"), message);
		}
	}

	public void log(Throwable throwable) {
		if (this.debug) {
			logger.log(Level.parse("ERROR"), "erro detectado no processo de autenticação", throwable);
		}
	}
}
