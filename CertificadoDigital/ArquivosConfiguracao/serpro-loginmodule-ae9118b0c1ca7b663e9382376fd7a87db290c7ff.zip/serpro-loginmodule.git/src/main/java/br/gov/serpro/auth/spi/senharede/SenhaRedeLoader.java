package br.gov.serpro.auth.spi.senharede;

import java.security.cert.X509Certificate;
import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.SerializationUtils;

import br.gov.serpro.auth.Profile;
import br.gov.serpro.auth.Transaction;
import br.gov.serpro.auth.SerproPrincipal.UserPrincipalBuilder;
import br.gov.serpro.auth.spi.Loader;
import br.gov.serpro.auth.spi.Util;
import br.gov.serpro.auth.spi.x509.ICPBrasilUtil;

public class SenhaRedeLoader implements Loader {

	private Util util;
	
	private String ip;

	private UserPrincipalBuilder builder;

	private boolean returnProfile;
	
	private SenhaRedeProxy proxy;

	@Override
	public String getAlias() {
		return "SENHAREDE";
	}

	@Override
	public void initialize(Map<String, ?> options,
			UserPrincipalBuilder builder, Util util) throws Exception {
		this.util = util;
		this.builder = builder;
		this.returnProfile = util.getOption("senharede.return.profile",
				Boolean.class, true, options);
		this.proxy = new SenhaRedeProxy(options, util);
		this.ip = "127.0.0.1";
	}

	@Override
	public boolean load(byte[] userAuthenticated) throws Exception {
		Object id = SerializationUtils.deserialize(userAuthenticated);
		return (id instanceof X509Certificate) ? loadByCertificate(userAuthenticated) : loadByCPF(userAuthenticated);
	}

	private boolean loadByCPF(byte[] userAuthenticate) {
		boolean loaded = false;
		
		String name = SenhaRedeProxy.getUserCredential().getName();
		String organId = SenhaRedeProxy.getUserCredential().getOrganId();
		String sector = SenhaRedeProxy.getUserCredential().getSector();
		String local = SenhaRedeProxy.getUserCredential().getLocal();
		String pahu = SenhaRedeProxy.getUserCredential().getPahu();
		Collection<Profile> profiles = convertSenhaRedeProfilesToSerproProfiles(SenhaRedeProxy
				.getUserCredential().getProfiles()) != null ? convertSenhaRedeProfilesToSerproProfiles(
						SenhaRedeProxy.getUserCredential().getProfiles()) : null;
						
		loaded = loadBuilder(name, organId, sector, local, pahu, profiles, loaded);			
		String cpf = (String) SerializationUtils.deserialize(userAuthenticate);	
		displayLog(cpf,loaded);
		
		return loaded;
	}
	
	private boolean loadByCertificate(byte[] userAuthenticated) throws Exception {
		boolean loaded = false;
		
		Object cert = SerializationUtils.deserialize(userAuthenticated);
		proxy.autenticate((X509Certificate) cert);
		
		String name = SenhaRedeProxy.getUserCertCredential().getUserCredential().getName();
		String organId = SenhaRedeProxy.getUserCertCredential().getUserCredential().getOrganId();
		String sector = SenhaRedeProxy.getUserCertCredential().getUserCredential().getSector();
		String local = SenhaRedeProxy.getUserCertCredential().getUserCredential().getLocal();
		String pahu = SenhaRedeProxy.getUserCertCredential().getUserCredential().getPahu();
		Collection<Profile> profiles = convertSenhaRedeProfilesToSerproProfiles(SenhaRedeProxy.
				getUserCertCredential().getUserCredential().getProfiles());
		
		loaded = loadBuilder(name, organId, sector, local, pahu, profiles, loaded);
		String cpf = ICPBrasilUtil.getCpfFromCertificate((X509Certificate) cert);
		displayLog(cpf, loaded);
		
		return loaded;
	}

	private boolean loadBuilder(String name, String organId, String sector,
			String local, String pahu, Collection<Profile> profiles, boolean loaded) {
		
		loaded |= (name != null);
		builder.fullName(name != null ? name : null);
		
		loaded |= (organId != null);
		builder.organId(organId != null ? organId : null);
		
		loaded |= (sector != null);
		builder.sectorId(sector != null ? sector : null);
		
		loaded |= (local != null);
		builder.subSector(local != null ? local : null);
		
		loaded |= (ip != null);
		builder.ip(ip != null ? ip : null);
		
		loaded |= (pahu != null);
		builder.subSector(pahu != null ? pahu : null);
		
		if (returnProfile) {
			loaded |= (profiles != null);
			builder.profiles(profiles);
		}		
		
		return loaded;
	}

	private void displayLog(String cpf, boolean loaded) {
		if (loaded) {
			this.util.log("usuário " + cpf + " carregado com sucesso");
		} else {
			this.util.log("usuário " + cpf + " não foi carregado: verifique as permissões da conexão");
		}		
	}
	
	private Collection<Profile> convertSenhaRedeProfilesToSerproProfiles(
			serpro.servicoscorporativos.senharede.authentication.v1.Profile[] senhareProfiles) {
		
		Set<Profile> profiles = new HashSet<Profile>();
		
		if (senhareProfiles != null && senhareProfiles.length > 0) {
			
			for (serpro.servicoscorporativos.senharede.authentication.v1.Profile senhareProfile : senhareProfiles) {
				
				Profile profile = new Profile();
				profile.setName(senhareProfile.getDescription().trim().toUpperCase());
				
				if (senhareProfile != null && senhareProfile.getTransactions() != null
						&& senhareProfile.getTransactions().length > 0) {
					
					profile.setTransactions(new HashSet<Transaction>());
					for (serpro.servicoscorporativos.senharede.authentication.v1.Transaction senhaRedeTransaction : 
						senhareProfile.getTransactions()) {
						
						Transaction transaction = new Transaction();
						transaction.setName(senhaRedeTransaction.getDescription().trim().toUpperCase());
						profile.getTransactions().add(transaction);
					}
				}

				profiles.add(profile);
			}
		}
		return profiles;
	}

	@Override
	public void close() {
		proxy.close();
	}
}
