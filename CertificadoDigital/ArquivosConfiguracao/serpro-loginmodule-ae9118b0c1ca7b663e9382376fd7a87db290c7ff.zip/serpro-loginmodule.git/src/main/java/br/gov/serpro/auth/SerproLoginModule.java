/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth;

import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ServiceLoader;
import java.util.logging.Logger;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import org.apache.commons.lang.SerializationUtils;

import br.gov.serpro.auth.SerproPrincipal.UserPrincipalBuilder;
import br.gov.serpro.auth.spi.Aliased;
import br.gov.serpro.auth.spi.Authenticator;
import br.gov.serpro.auth.spi.Loader;
import br.gov.serpro.auth.spi.Util;
import br.gov.serpro.auth.spi.x509.ICPBrasilUtil;

/**
 * @see <a href="http://docs.oracle.com/javase/7/docs/technotes/guides/security/jaas/JAASLMDevGuide.html#Step_1">Java
 *      Authentication and Authorization Service (JAAS): LoginModule Developer's Guide</a>
 */
public class SerproLoginModule implements LoginModule {

	private CallbackHandler callbackHandler;

	private static final Logger logger = Logger.getLogger(SerproLoginModule.class.getName());

	private boolean debug;

	private Subject subject;

	private SerproPrincipal user;

	private Map<String, ?> options;

	private List<String> authenticators;

	private List<String> loaders;

	private Util util;

	private byte [] userAuthenticated;
	
	private String cpf;

	@Override
	public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState,
			Map<String, ?> options) {
		this.subject = subject;
		this.callbackHandler = callbackHandler;
		this.options = options;
		this.util = new Util(logger);

		loadOptions(options);
	}

	private void loadOptions(Map<String, ?> options) {
		this.debug = util.getOption("debug", Boolean.class, false, this.options);
		this.util.setDebug(this.debug);

		this.authenticators = new ArrayList<String>();
		String[] authenticators = util.getOption("authenticator", String.class, "LDAP", this.options).split(",");
		for (String authenticator : authenticators) {
			this.authenticators.add(authenticator.trim().toLowerCase());
		}

		this.loaders = new ArrayList<String>();
		String[] loaders = util.getOption("loader", String.class, "SIMPLE", this.options).split(",");
		for (String loader : loaders) {
			this.loaders.add(loader.trim().toLowerCase());
		}
	}

	private List<Authenticator> loadAuthenticators(List<String> authenticators) throws Exception {
		List<Authenticator> active = new ArrayList<Authenticator>();
		loadBasedOnAlias(active, Authenticator.class, authenticators);

		for (Authenticator authenticator : active) {
			Logger logger = Logger.getLogger(authenticator.getClass().getName());
			Util util = new Util(logger);
			util.setDebug(this.debug);

			this.util.log("iniciando o autenticador " + authenticator.getClass().getName());
			authenticator.initialize(options, util);
		}

		return active;
	}

	private List<Loader> loadLoaders(List<String> loaders, UserPrincipalBuilder builder) throws Exception {
		List<Loader> active = new ArrayList<Loader>();
		loadBasedOnAlias(active, Loader.class, this.loaders);

		for (Loader loader : active) {
			Logger logger = Logger.getLogger(loader.getClass().getName());
			Util util = new Util(logger);
			util.setDebug(this.debug);

			this.util.log("iniciando o carregador " + loader.getClass().getName());
			loader.initialize(options, builder, util);
		}

		return active;
	}

	private <T extends Aliased> void loadBasedOnAlias(List<T> aliasedList, Class<T> aliasedType, List<String> list) {
		ServiceLoader<T> serviceLoader = ServiceLoader.load(aliasedType);
		Iterator<T> it = serviceLoader.iterator();

		while (it.hasNext()) {
			T aliased = it.next();
			String alias = aliased.getAlias();

			if (list.contains(alias.toLowerCase())) {
				aliasedList.add(aliased);
				this.util.log("ativando " + alias + ": " + aliased.getClass().getName());
			}
		}
	}

	@Override
	public boolean login() throws LoginException {
		Authenticator selected = null;

		try {
			selected = selectAuthenticator();

			if (selected != null) {
				this.util.log("autenticando com " + selected.getClass().getName());
				this.userAuthenticated = selected.authenticate();
			}

		} catch (LoginException cause) {
			throw cause;

		} catch (Exception cause) {
			this.util.log(cause);

		} finally {
			if (selected != null) {
				selected.close();
			}
		}

		if (isAuthenticated()) {
			
			Object id = SerializationUtils.deserialize(this.userAuthenticated);
			
			cpf = (id instanceof X509Certificate) ? 
					ICPBrasilUtil.getCpfFromCertificate((X509Certificate) id) : (String) id;
			
			this.util.log("usuário " + this.cpf + " autenticado");

		} else if (selected != null) {
			throw new FailedLoginException(selected.getLoginFailedMessage());
		}

		return selected != null;
	}

	private void handleCallbacks(Callback[] callbacks) throws IOException {
		try {
			callbackHandler.handle(callbacks);

		} catch (UnsupportedCallbackException cause) {
			this.util.log(cause);
		}
	}

	private Authenticator selectAuthenticator() throws Exception {
		Map<Authenticator, Callback[]> map = new HashMap<Authenticator, Callback[]>();
		List<Authenticator> authenticators = loadAuthenticators(this.authenticators);

		for (Authenticator authenticator : authenticators) {
			map.put(authenticator, authenticator.getCallBacks());
		}

		for (Callback[] callbacks : map.values()) {
			handleCallbacks(callbacks);
		}

		Authenticator selected = null;

		for (Authenticator authenticator : map.keySet()) {
			if (authenticator.isSupported()) {
				selected = authenticator;
				break;
			}
		}

		return selected;
	}

	@Override
	public boolean commit() throws LoginException {
		boolean commited = false;
		boolean loaded = false;

		if (isAuthenticated()) {
			try {
				UserPrincipalBuilder builder = SerproPrincipal.cpf(this.cpf);
				List<Loader> loaders = loadLoaders(this.loaders, builder);

				for (Loader loader : loaders) {
					this.util.log("carregando dados do usuário com " + loader.getClass().getName());
					loaded |= loader.load(this.userAuthenticated);
					loader.close();
				}

				user = builder.build();

			} catch (Exception cause) {
				this.util.log(cause);
				loaded = false;
			}
		}

		if (loaded) {
			this.subject.getPrincipals().add(user);
			commited = true;
		} else if (isAuthenticated()) {
			throw new FailedLoginException("usuário inválido");
		} else {
			commited = false;
		}

		clear();
		return commited;
	}

	private boolean isAuthenticated() {
		//TODO: Verificar chamar método isLoggedIn do SecurutyContext
		return this.userAuthenticated != null;
	}

	private void clear() {
		this.cpf = null;
	}

	@Override
	public boolean abort() throws LoginException {
		clear();
		return true;
	}

	@Override
	public boolean logout() throws LoginException {
		boolean result = false;

		if (user != null) {
			this.subject.getPrincipals().remove(this.user);
			this.user = null;
			result = true;

		} else {
			throw new LoginException("Falha no logout");
		}

		return result;
	}
}
