package br.gov.serpro.auth.spi.x509;

import java.security.cert.X509Certificate;

import br.gov.frameworkdemoiselle.certificate.CertificateManager;

public class ICPBrasilUtil {

	public static String getCpfFromCertificate(X509Certificate certificate){
		CertificateManager cm = new CertificateManager(certificate);
		ICPBrasilPerson user = cm.load(ICPBrasilPerson.class);

		return user.getCpf().isEmpty() ? null : user.getCpf();
	}
}
