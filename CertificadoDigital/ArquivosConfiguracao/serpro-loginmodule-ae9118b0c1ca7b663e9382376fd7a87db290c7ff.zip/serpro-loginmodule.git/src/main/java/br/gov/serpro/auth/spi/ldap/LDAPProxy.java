/*
 * SERPRO Artifacts
 * Copyright (C) 2014 SERPRO
 * ----------------------------------------------------------------------------
 * This file is part of SERPRO Artifacts.
 * 
 * SERPRO Artifacts is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License version 3
 * along with this program; if not,  see <http://www.gnu.org/licenses/>
 * or write to the Free Software Foundation, Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA  02110-1301, USA.
 * ----------------------------------------------------------------------------
 * Este arquivo é parte do SERPRO Artifacts.
 * 
 * O SERPRO Artifacts é um software livre; você pode redistribuí-lo e/ou
 * modificá-lo dentro dos termos da GNU LGPL versão 3 como publicada pela Fundação
 * do Software Livre (FSF).
 * 
 * Este programa é distribuído na esperança que possa ser útil, mas SEM NENHUMA
 * GARANTIA; sem uma garantia implícita de ADEQUAÇÃO a qualquer MERCADO ou
 * APLICAÇÃO EM PARTICULAR. Veja a Licença Pública Geral GNU/LGPL em português
 * para maiores detalhes.
 * 
 * Você deve ter recebido uma cópia da GNU LGPL versão 3, sob o título
 * "LICENCA.txt", junto com esse programa. Se não, acesse <http://www.gnu.org/licenses/>
 * ou escreva para a Fundação do Software Livre (FSF) Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA 02111-1301, USA.
 */
package br.gov.serpro.auth.spi.ldap;

import static javax.naming.Context.INITIAL_CONTEXT_FACTORY;
import static javax.naming.Context.PROVIDER_URL;
import static javax.naming.Context.SECURITY_CREDENTIALS;
import static javax.naming.Context.SECURITY_PRINCIPAL;
import static javax.naming.directory.SearchControls.SUBTREE_SCOPE;

import java.util.Hashtable;
import java.util.Map;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.security.auth.login.LoginException;

import br.gov.serpro.auth.spi.Util;

public class LDAPProxy {

	private Util util;

	private LdapContext context;

	private String contextFactory;

	private String providerUrl;

	private String bindDN;

	private String bindPassword;

	private String searchContext;

	private String searchFilter;

	public LDAPProxy(Map<String, ?> options, Util util) throws NamingException {
		this.util = util;

		loadOptions(options);
		loadLdapContext();
	}

	private void loadOptions(Map<String, ?> options) {
		this.contextFactory = util.getOption("ldap.context.factory", String.class, "com.sun.jndi.ldap.LdapCtxFactory",
				options);
		this.providerUrl = util
				.getOption("ldap.provider.url", String.class, "ldap://slave-sdr-reg.sdr.serpro", options);
		this.bindDN = util.getOption("ldap.bind.dn", String.class, null, options);
		this.bindPassword = util.getOption("ldap.bind.password", String.class, null, options);
		this.searchContext = util.getOption("ldap.search.context", String.class, "dc=serpro,dc=gov,dc=br", options);
		this.searchFilter = util.getOption("ldap.search.filter", String.class, "(uid={username})", options);
	}

	public String getDN(String username) throws Exception {
		String dn = null;
		String parsedFilter = this.searchFilter.replaceAll("\\{username\\}", username);
		NamingEnumeration<?> results = search(this.searchContext, parsedFilter, SUBTREE_SCOPE);

		if (results.hasMore()) {
			SearchResult result = (SearchResult) results.next();
			dn = result.getNameInNamespace();
		}

		this.util.log("DN associado a " + username + ": " + dn);

		if (dn == null) {
			throw new LoginException();
		}

		return dn;
	}

	public Attributes getAttributes(String dn) throws NamingException {
		this.util.log("consultando atributos do DN " + dn);
		Attributes attributes = context.getAttributes(dn);
		this.util.log("consulta de atributos finalizada do DN " + dn);

		return attributes;
	}

	private NamingEnumeration<SearchResult> search(String searchContext, String searchFilter, int scope)
			throws NamingException {
		SearchControls cons = new SearchControls();
		cons.setSearchScope(scope);
		return context.search(searchContext, searchFilter, cons);
	}

	public void authenticate() throws NamingException {
		authenticate(this.bindDN, this.bindPassword);
	}

	public void authenticate(String bindDN, String bindPassword) throws NamingException {
		this.util.log("autenticando conexão LDAP utilizando o DN " + bindDN);

		if (bindDN != null) {
			this.context.addToEnvironment(SECURITY_PRINCIPAL, bindDN);
		}

		if (bindPassword != null) {
			this.context.addToEnvironment(SECURITY_CREDENTIALS, bindPassword);
		}

		this.context.reconnect(null);
		this.util.log("conexão LDAP restabelecida utilizando o DN " + bindDN);
	}

	private void loadLdapContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(INITIAL_CONTEXT_FACTORY, this.contextFactory);
		env.put(PROVIDER_URL, this.providerUrl);

		this.context = new InitialLdapContext(env, null);
		this.util.log("conexão LDAP estabelecida: " + this.providerUrl);
	}

	public void close() throws NamingException {
		this.util.log("fechando conexão com o LDAP: " + this.context.getEnvironment().get(PROVIDER_URL));
		this.context.close();
	}
}
