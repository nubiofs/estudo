package br.gov.serpro.auth.spi.senharede;

import br.gov.serpro.auth.spi.Util;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Map;

import javax.naming.NamingException;
import javax.xml.rpc.ServiceException;

import serpro.servicoscorporativos.senharede.authentication.v1.AuthenticateByCertificateData;
import serpro.servicoscorporativos.senharede.authentication.v1.AuthenticateCertificateCredencial;
import serpro.servicoscorporativos.senharede.authentication.v1.AuthenticateData;
import serpro.servicoscorporativos.senharede.authentication.v1.AuthenticationFault;
import serpro.servicoscorporativos.senharede.authentication.v1.InternalFault;
import serpro.servicoscorporativos.senharede.authentication.v1.MalformedMessageFault;
import serpro.servicoscorporativos.senharede.authentication.v1.UserCredential;
import serpro.servicoscorporativos.senharede.authentication.v1.UserInfo;
import serpro.servicoscorporativos.senharede.ws.authenticationservice.authenticationserviceendpoint.v1.AuthenticationPortType;
import serpro.servicoscorporativos.senharede.ws.authenticationservice.authenticationserviceendpoint.v1.AuthenticationServiceHTTPServiceagentLocator;

public class SenhaRedeProxy {
	
	private static final String DEFAULT_URL = "https://desautenticacao.senharede.servicoscorporativos.serpro:8082/"
			+ "AuthenticationServiceEndpointHTTP/v1.0";
	
	private static final String DEFAULT_SYSTEM = "SGP";
	
	//IP do usuário final que está acessando a aplicação, utilizado para auditoria. 
	//A aplicação que precisar desse recurso deve implementar o método para capturar 
	//essa informação e adicionar ao Serpro-Principal
	private String ip;
	
	private Util util;
	
	private AuthenticationPortType authenticationPortType;
	
	private String providerUrl; 
	
	private String system;
	
	private boolean returnProfile;
	
	private AuthenticateData authenticateData;
	
	private AuthenticateByCertificateData authenticateCertData;
	
	private static UserCredential userCredential;
	
	private static AuthenticateCertificateCredencial userCertCredential;
	
	private String exceptionMessage;
	
	protected SenhaRedeProxy(Map<String, ?> options, Util util) throws NamingException {
		
		this.util = util;
		loadOptions(options);
		ip = "127.0.0.1";
	}

	private void loadOptions(Map<String, ?> options) {
		this.providerUrl = util.getOption("senharede.provider.url", String.class, DEFAULT_URL, options);
		this.system = util.getOption("senharede.system", String.class, DEFAULT_SYSTEM, options);
		this.returnProfile = util.getOption("senharede.return.profile",
				Boolean.class, true, options);
	}
	
	private void loadAuthenticateData(String username, String password) {
		UserInfo userInfo = new UserInfo(username, password, null, ip);
		authenticateData = new AuthenticateData(userInfo, system, returnProfile);
	}
	

	public void authenticate(String username, String password) throws Exception {
		loadAuthenticateData(username, password);
		
		try {
			URL url = new URL(providerUrl);
			
			authenticationPortType = new AuthenticationServiceHTTPServiceagentLocator().
					getAuthenticationPortTypeEndpointHTTP(url);
			
			userCredential = authenticationPortType.authenticate(authenticateData);
		} catch (InternalFault ife) {
			ife.printStackTrace();
			this.exceptionMessage = ife.getDescription();
			throw ife;
		} catch (AuthenticationFault afe) {
			afe.printStackTrace();
			this.exceptionMessage = afe.getDescription();
			throw afe;
		} catch (MalformedMessageFault mme) {
			mme.printStackTrace();
			this.exceptionMessage = mme.getDescription();
			throw mme;
		} catch (ServiceException se) {
			se.printStackTrace();
			this.exceptionMessage = se.getMessage();
			throw se;
		} catch (MalformedURLException mue) {
			mue.printStackTrace();
			this.exceptionMessage = mue.getMessage();
			throw mue;
		} catch (RemoteException re) {
			re.printStackTrace();
			this.exceptionMessage = re.getMessage();
			throw re;
		} catch (Exception e){
			e.printStackTrace();
			this.exceptionMessage = e.getMessage();
			throw e;
		}
	}
	
	public void autenticate(X509Certificate cert) throws Exception{
		loadAuthenticateData(cert);
		
		try{
			URL url = new URL(providerUrl);
			
			authenticationPortType = new AuthenticationServiceHTTPServiceagentLocator().
					getAuthenticationPortTypeEndpointHTTP(url);
			
			userCertCredential = authenticationPortType.authenticateByCertificate(authenticateCertData);
		} catch (InternalFault ife) {
			ife.printStackTrace();
			this.exceptionMessage = ife.getDescription();
			throw ife;
		} catch (AuthenticationFault afe) {
			afe.printStackTrace();
			this.exceptionMessage = afe.getDescription();
			throw afe;
		} catch (MalformedMessageFault mme) {
			mme.printStackTrace();
			this.exceptionMessage = mme.getDescription();
			throw mme;
		} catch (ServiceException se) {
			se.printStackTrace();
			this.exceptionMessage = se.getMessage();
			throw se;
		} catch (MalformedURLException mue) {
			mue.printStackTrace();
			this.exceptionMessage = mue.getMessage();
			throw mue;
		} catch (RemoteException re) {
			re.printStackTrace();
			this.exceptionMessage = re.getMessage();
			throw re;
		} catch (Exception e){
			e.printStackTrace();
			this.exceptionMessage = e.getMessage();
			throw e;
		}
	}
	
	private void loadAuthenticateData(X509Certificate cert) throws CertificateEncodingException {
		authenticateCertData = new AuthenticateByCertificateData(ip, cert.getEncoded(), system, returnProfile);
	}

	public void close(){
		// TODO Auto-generated method stub
	}
	
	public static UserCredential getUserCredential(){
		return userCredential;
	}
	
	public static AuthenticateCertificateCredencial getUserCertCredential(){
		return userCertCredential;
	}
	
	public String getExceptionMessage(){
		return this.exceptionMessage;
	}
}
