# SERPRO Login Module

Opção de Login Module integrado com os mecanismos de autenticação do SERPRO. Atualmente suporta LDAP, Senha Rede e
Certificado digital no formato ICP-Brasil.

**Conteúdo**

1. [Configuração](#1-configura-o)
	1. [JBoss EAP](#1-1-jboss-eap)
2. [Propriedades](#2-propriedades)
	1. [Geral](#2-1-geral)
	2. [LDAP](#2-2-ldap)
	3. [Senha Rede](#2-3-senha-rede)
3. [Customização](#3-customiza-o)
4. [Exemplos](#4-exemplos)
	1. [LDAP + Certificado ICP-Brasil](#4-1-ldap-certificado-icp-brasil)
	2. [Senha Rede + Certificado ICP-Brasil](#4-2-senha-rede-certificado-icp-brasil)
5. [Relacionados](#5-relacionados)
6. [Contribuições](#6-contribui-es)
	
## 1. Configuração

### 1.1. JBoss EAP

Toda a configuração deve ser feita no `standalone.xml`. Na seção `security-domains` basta criar o seu `security-domain` e configurar o SerproLoginModule. 

Para o caso de autenticação com o LDAP, é necessário definir os seguintes atributos: 

```xml
<security-domain name="other" cache-type="default">
    <authentication>
        <login-module code="br.gov.serpro.auth.SerproLoginModule" flag="required">
            <module-option name="ldap.context.factory" value="com.sun.jndi.ldap.LdapCtxFactory"/>
            <module-option name="ldap.provider.url" value="ldap://slave-sdr-reg.sdr.serpro"/>
            <module-option name="ldap.bind.dn" value="uid=webdesdr,ou=Servicos,ou=corp,dc=serpro,dc=gov,dc=br"/>
            <module-option name="ldap.bind.password" value="*********"/>
        </login-module>
    </authentication>
</security-domain>
```

Lembre-se de definir os atributos `ldap.bind.dn` e `ldap.bind.password` com os valores da sua regional. 

Para autenticação através do serviço Senha Rede os atributos necessários são os seguintes:

```xml
<security-domain name="other" cache-type="default">
    <authentication>
        <login-module code="br.gov.serpro.auth.SerproLoginModule" flag="required">
            <module-option name="senharede.provider.url" value="https://desautenticacao.senharede.servicoscorporativos.serpro:8082/AuthenticationServiceEndpointHTTP/v1.0"/>
			 <module-option name="senharede.system" value="SGP"/>
        </login-module>
    </authentication>
</security-domain>
```

Localize o _subsystem_ `jboss:domain:ee` e adicione o seguinte trecho:

```xml
<global-modules>
    <module name="br.gov.serpro.loginmodule" slot="main"/>
</global-modules>
```

Baixe o arquivo [serpro-loginmodule-1.0.0-jboss.zip](http://nexus.aic.serpro/service/local/repositories/componentes-corporativos/content/br/gov/serpro/serpro-loginmodule/1.1.0/serpro-loginmodule-1.1.0-jboss.zip) e descompacte o conteúdo da pasta `modules` dentro da pasta `modules` do seu JBoss EAP.

## 2. Propriedades

### 2.1. Geral
Configurações gerais do Login Module:

| atributo | descrição | valores | opcional | valor padrão | 
| -------- | --------- | ------- |:--------:| ------------ |
| `authenticator` | Define a estratégia de autenticação do módulo. Aceita mais de um autenticador simultâneo. | `LDAP`, `SENHAREDE` e `CERT` | sim | `LDAP` |
| `loader` | Define a estratégia de carregamento do SeproPrincipal. Aceita mais de um carregador simultâneo. | `SIMPLE`, `LDAP` e `SENHAREDE` | sim | `SIMPLE` |
| `debug` | Ativa o log de debug do Login Module. | `true` ou `false` | sim | `false` |

### 2.2. LDAP
Configurações utilzadas pelo authenticator e loader para LDAP:

| atributo | descrição | opcional | valor padrão | 
| -------- | --------- | :-------:| ------------ |
| `ldap.context.factory` | Define o atributo `INITIAL_CONTEXT_FACTORY` da conexão. | sim | `com.sun.jndi.ldap.LdapCtxFactory` |
| `ldap.provider.url` | URL da conexão. | sim | `ldap://slave-sdr-reg.sdr.serpro` |
| `ldap.bind.dn` | DN obrigatório utilizado na conexão com o LDAP. | não | |
| `ldap.bind.password` | Senha obrigatória utilizada na conexão com o LDAP. | não | |
| `ldap.search.context` | Contexto de busca. | sim | `dc=serpro,dc=gov,dc=br` | 
| `ldap.search.filter` | Parâmetro de busca padrão LDAP Search. | sim | `(uid={username})` |

### 2.3. Senha Rede
Configurações utilzadas pelo authenticator e loader para SENHAREDE:

| atributo | descrição | opcional | valor padrão | 
| -------- | --------- | :-------:| ------------ |
| `senharede.provider.url` | URL da conexão. | sim | `https://desautenticacao.senharede.servicoscorporativos.serpro:``8082/AuthenticationServiceEndpointHTTP/v1.0` |
| `senharede.system` | Sistema no qual será realizada a autenticação. | sim | `SGP` |
| `senharede.return.profile` | Parâmetro que indica se será retornado o perfil do usuário logado. | sim | `true` |

## 3. Customização

Você pode criar novos authenticators e loaders. O [Authenticator](http://gitlab.serpro/demoiselle/serpro-loginmodule/blob/master/src/main/java/br/gov/serpro/auth/spi/Authenticator.java)
é responsável por autenticar o usuário, enquanto o [Loader](http://gitlab.serpro/demoiselle/serpro-loginmodule/blob/master/src/main/java/br/gov/serpro/auth/spi/Loader.java)
carrega as informações do SerproPrincipal.

Para criar seus autenticadores e carregadores implemente as respectivas interfaces e empacote-as em um JAR. Dentro do JAR crie a pasta `META-INF/services` contendo
dois arquivos com os seguintes nomes: `br.gov.serpro.auth.spi.Authenticator` e `br.gov.serpro.auth.spi.Loader`. Dentro de cada um deles declare as suas classes customizadas
de autenticador e carregador respectivamente, tais como [este exemplo](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master/src/main/resources/META-INF/services).

Por fim, mova o JAR para a pasta `{JBOSS_EAP}/modules/br/gov/serpro/loginmodule/main/` e acrescente o seguinte `resource-root`:

```xml
<resource-root path="SEU_ARQUIVO.jar"/>
```

## 4. Exemplos

### 4.1. LDAP + Certificado ICP-Brasil

Este exemplo mostra como configurar a autenticação via LDAP ou Certificado Digital ICP-Brasil carregando o usuário logado com os dados do LDAP.
O Login Module estará disponível com o nome `serpro-auth-ldap` e acessará o servidor de Brasília:

```xml
<security-domain name="serpro-auth-ldap" cache-type="default">
    <authentication>
        <login-module code="br.gov.serpro.auth.SerproLoginModule" flag="required">
            <module-option name="ldap.context.factory" value="com.sun.jndi.ldap.LdapCtxFactory"/>
            <module-option name="ldap.provider.url" value="ldap://slave-bsa-reg.bsa.serpro"/>
            <module-option name="ldap.bind.dn" value="uid=webdebsa,ou=Servicos,ou=corp,dc=serpro,dc=gov,dc=br"/>
            <module-option name="ldap.bind.password" value="*********"/>
            <module-option name="authenticator" value="LDAP,CERT"/>
            <module-option name="loader" value="LDAP"/>
            <module-option name="debug" value="true"/>
        </login-module>
    </authentication>
</security-domain>
```

Baixe o arquivo [serpro-loginmodule-1.0.0-jks.zip](http://nexus.aic.serpro/service/local/repositories/componentes-corporativos/content/br/gov/serpro/serpro-loginmodule/1.0.0/serpro-loginmodule-1.0.0-jks.zip) e descompacte-o na pasta `standalone/configuration` do seu JBoss EAP.

Inclua o conector que receberá o certificado do cliente na seção `urn:jboss:domain:web` do `standalone.xml` do JBoss EAP:

```xml
<connector name="https-clientcert" protocol="HTTP/1.1" scheme="https" socket-binding="https-clientcert" secure="true">
    <ssl name="https" key-alias="localhost" password="changeit"
		certificate-key-file="${jboss.server.config.dir}/Keystore.jks"
		ca-certificate-file="${jboss.server.config.dir}/Truststore.jks"
		protocol="TLSv4" verify-client="true" />
</connector>
```

Declare também o `socket-binding` na seção `socket-binding-group` referenciando o conector:

```xml
<socket-binding name="https-clientcert" port="8444"/>
```

### 4.2. Senha Rede + Certificado ICP-Brasil

No caso de autenticação via Senha Rede ou Certificado Digital ICP-Brasil carregando o usuário logado com os dados do Senha Rede, o procedimento é bastante parecido. O security-domain, pode ficar assim:

```xml
<security-domain name="serpro-auth-senharede" cache-type="default">
    <authentication>
        <login-module code="br.gov.serpro.auth.SerproLoginModule" flag="required">
            <module-option name="senharede.provider.url" value="https://homautenticacao.senharede.servicoscorporativos.serpro:8444/AuthenticationServiceEndpointHTTP/v1.0"/>
            <module-option name="senharede.system" value="SGP"/>
            <module-option name="senharede.return.profile" value="false"/>
            <module-option name="authenticator" value="SENHAREDE,CERT"/>
            <module-option name="loader" value="SENHAREDE"/>
            <module-option name="debug" value="true"/>
        </login-module>
    </authentication>
</security-domain>
```
Dessa forma o Login Module estará disponível com o nome `serpro-auth-senharede`, e acessará um serviço utilizado para homologação na autenticação via serviço Senha Rede.

Outra diferença está na configuração da conexão segura. Essa diferença está essencialmente nos arquivos de keystore e truststore específicos, e uma configuração na VM. Para baixar os arquivos necessários e realizar as configurações complementares (além de verificar as URL's disponíveis para acessar o serviço senha rede) consulte o site do [Serviço Senha Rede](http://himalaia.bhe.serpro/wiki/index.php/Servi%C3%A7o_Senha_Rede).

## 5. Relacionados

| projeto | descrição | 
| -------- | --------- |
| [serpro-javax-api](http://gitlab.serpro/demoiselle/serpro-javax-api/tree/master) | Interfaces referentes à spec `javax` especializadas para o SERPRO. |
| [serpro-demoiselle-loginmodule-jsf](http://gitlab.serpro/demoiselle/serpro-demoiselle-loginmodule-jsf/tree/master) | Implementação para ativar autenticação JAAS e Certificado ICP-Brasil em aplicações que utilizam JSF. |
| [serpro-demoiselle-rest](http://gitlab.serpro/demoiselle/serpro-demoiselle-rest/tree/master) | Implementação para ativar autenticação JAAS e Certificado ICP-Brasil em aplicações REST. |
| [serpro-loginmodule-exemplo-jsf](http://gitlab.serpro/demoiselle/serpro-loginmodule-exemplo-jsf/tree/master) | Aplicação desenvolvida a partir do arquétipo demoisele-jsf-jpa que utiliza o componente serpro-demoiselle-loginmodule-jsf. |
| [serpro-loginmodule-exemplo-html-rest](http://gitlab.serpro/demoiselle/serpro-loginmodule-exemplo-html-rest/tree/master) | Aplicação desenvolvida a partir do arquétipo demoiselle-html-rest que utiliza o componente serpro-demoiselle-rest. |


## 6. Contribuições

Você pode contribuir de diversas formas com este projeto.

*	**Bug**: Se você achou erro ou deseja uma nova funcionalidade,
informe aqui [neste link](http://gitlab.serpro/demoiselle/serpro-loginmodule/issues/new?issue%5Bassignee_id%5D=&issue%5Bmilestone_id%5D=).

*	**Documentação**: Quer melhorar este material? Crie seu _fork_, melhore a documentação e faça o _Pull Request_.

*	**Código-fonte**: Disposto a melhorar algo ou criar novas funcionalidades? Sugerimos [discutir antes](http://gitlab.serpro/demoiselle/serpro-loginmodule/issues/new?issue%5Bassignee_id%5D=&issue%5Bmilestone_id%5D=)
de enviar o _Pull Resquest_.

Aguardamos a sua contribuição.