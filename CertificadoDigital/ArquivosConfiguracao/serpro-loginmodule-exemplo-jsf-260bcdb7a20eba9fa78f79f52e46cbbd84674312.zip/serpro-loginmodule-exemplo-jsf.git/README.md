# Exemplo de Autenticação com Aplicação JSF

Para rodar essa aplicação é necessário seguir a documentação apresentada no projeto [serpro-loginmodule](http://gitlab.serpro/demoiselle/serpro-loginmodule/tree/master/README.md), e configurar adequadamente o servidor de aplicação.
O nome esperado para o `security-domain` é "serpro-ldap", e você pode modificar esse nome no arquivo `demoiselle.properties`, conforme descrito no projeto [serpro-demoiselle-loginmodule-jsf](http://gitlab.serpro/demoiselle/serpro-demoiselle-loginmodule-jsf/tree/master/README.md).