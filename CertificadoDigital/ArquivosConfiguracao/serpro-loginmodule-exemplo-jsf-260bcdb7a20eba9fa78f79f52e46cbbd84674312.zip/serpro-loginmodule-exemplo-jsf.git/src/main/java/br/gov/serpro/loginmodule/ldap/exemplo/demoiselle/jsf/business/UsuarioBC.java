package br.gov.serpro.loginmodule.ldap.exemplo.demoiselle.jsf.business;

import br.gov.frameworkdemoiselle.lifecycle.Startup;
import br.gov.frameworkdemoiselle.stereotype.BusinessController;
import br.gov.frameworkdemoiselle.template.DelegateCrud;
import br.gov.frameworkdemoiselle.transaction.Transactional;
import br.gov.serpro.loginmodule.ldap.exemplo.demoiselle.jsf.domain.Usuario;
import br.gov.serpro.loginmodule.ldap.exemplo.demoiselle.jsf.persistence.UsuarioDAO;

@BusinessController
public class UsuarioBC extends DelegateCrud<Usuario, Long, UsuarioDAO> {
	
	private static final long serialVersionUID = 1L;
	
	@Startup
	@Transactional
	public void load() {
		if (findAll().isEmpty()) {
			//insert(new Usuario("02963357460", true));
			insert(new Usuario("02963357460", false));
		}
	}
	
}
