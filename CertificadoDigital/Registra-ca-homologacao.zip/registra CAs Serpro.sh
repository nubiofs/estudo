#!/bin/bash

clear

JAVA_HOME=/home/07721825741/Documentos/Aplicativos/Java/jdk1.6.0_45

NOME_KEYSTORE=$JAVA_HOME/jre/lib/security/cacerts

CASERPRO_HOME="CAHOMOLOGACAO"

keytool -delete -alias acserprov3 -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias ICP-Brasil -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias icpbrasilv2 -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias raiz.brasil -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias serproacfv3 -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias serpro.final -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias serprofinalv2 -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias serprov1 -keystore $NOME_KEYSTORE -storepass changeit

keytool -delete -alias serprov2 -keystore $NOME_KEYSTORE -storepass changeit

keytool -v -importcert -trustcacerts -alias acserprov3 -file $CASERPRO_HOME/acserprov3.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias ICP-Brasil -file $CASERPRO_HOME/ICP-Brasil.crt -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias icpbrasilv2 -file $CASERPRO_HOME/icpbrasilv2.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias raiz.brasil -file $CASERPRO_HOME/raiz.brasil.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias serproacfv3 -file $CASERPRO_HOME/serproacfv3.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias serpro.final -file $CASERPRO_HOME/serpro.final.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias serprofinalv2 -file $CASERPRO_HOME/serprofinalv2.crt -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias serprov1 -file $CASERPRO_HOME/serprov1.cer -keystore $NOME_KEYSTORE -storepass changeit -noprompt

keytool -v -importcert -trustcacerts -alias serprov2 -file $CASERPRO_HOME/serprov2.crt -keystore $NOME_KEYSTORE -storepass changeit -noprompt
