Jasper source files (*. jrxml)

Devido a problemas do plugin do maven para compilar os jrxml, os relatórios estão sendo compilados 
no iReport 5.6.0 com compatibilidade com a versão 5.1.2 do jasperreports.