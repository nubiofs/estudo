MongoDB implementations of Spring Batch meta-data persistency DAOs (ExecutionContextDao, JobExecutionDao, JobInstanceDao, StepExecutionDao).

Inspired by [springbatch-over-mongodb](https://github.com/jbaruch/springbatch-over-mongodb) and the current JDBC implementations.

It is based on Spring Batch 2.2.0.RELEASE.