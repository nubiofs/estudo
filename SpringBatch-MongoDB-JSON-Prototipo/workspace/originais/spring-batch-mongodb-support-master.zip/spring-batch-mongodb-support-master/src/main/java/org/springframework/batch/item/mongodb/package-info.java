/**
 * <a href="http://www.mongodb.org">MongoDB</a> support for the 
 * <a href="http://static.springsource.org/spring-batch">Spring Batch</a> framework.
 * 
 * @author <a href="mailto:tobias.trelle">Tobias Trelle</a>
 */
package org.springframework.batch.item.mongodb;