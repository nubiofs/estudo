# -*- coding: utf-8 -*-

import csv, os, datetime
from geopy.distance import vincenty

class Timepoint():
    """represent point in space and time defined through its lat and lon coordinates and datetime object"""
    def __init__(self, time, lat, lon):
        self.time = time  # time as a datetime object
        self.lat = lat    # latitude as a float
        self.lon = lon    # longitude as a float

class Bus():
    """represents an individual bus with all its GPS observation data"""
    def __init__(self, busId, line):
        self.busId = busId      # id of this bus as string
        self.line = line        # line this bus belongs to as string 
        self.timepoints = []    # gps points for this bus as list of Timepoint objects
            
    def readFromCSV(fileName, columnIndices):
        """reads comma-separated text file with each row representing a GPS point for a bus with timestamp and returns dictionary mapping
           bus id to created Bus objects. The column indices for the important info ('lat', 'lon', 'time', 'busID', 'line') need to be 
           provided in dictionary columnIndices.""" 
        buses = {}
        
        with open(os.path.join(os.path.dirname(__file__), fileName), "r") as trackFile:
            csvReader = csv.reader(trackFile, delimiter=',')
            for row in csvReader:
                # read required info from current row
                busId = row[columnIndices['busId']]
                lat = row[columnIndices['lat']]
                lon = row[columnIndices['lon']]
                time = row[columnIndices['time']]
                line = row[columnIndices['line']]
                
                # create datetime object from time; we here assume that time in the csv file is given in microseconds since January 1, 1970
                dt = datetime.datetime(1970, 1, 1) + datetime.timedelta(microseconds=int(time))
            
                # create and add new Bus object if this is the first point for this bus id, else take Bus object from the dictionary    
                if not busId in buses:
                    bus = Bus(busId, line)
                    buses[busId] = bus     
                else:
                    bus = buses[busId]
                
                # create Timepoint object for this row and add it to the bus's Timepoint list
                bus.timepoints.append(Timepoint(dt,float(lat),float(lon)))

        return buses  # return dictionary with Bus objects created

class BusTracker():
    """represents the current state of processing the GPS data of an individual Bus object including the current status of the bus"""
    STATUS_DRIVING = "DRIVING"
    STATUS_STOPPED = "STOPPED"
    STATUS_INDEPOT = "IN DEPOT"
    
    """represents the current state of processing the GPS data of an individual Bus object including the current status of the bus"""
    def __init__(self, bus):
        self.bus = bus                          # object of class Bus that this tracker will be tracking
        self.eventList = []                     # list of detected events this bus is involved in
        self.lastProcessedIndex = -1            # index of last processed Timepoint from bus's list of Timepoints
        self.status = BusTracker.STATUS_DRIVING # current status of bus as string (either "DRIVING", "IN DEPOT", or "STOPPED") 
        self.depot = None                       # Depot object for involved depot if bus has status "IN DEPOT"
        self.statusEvent = None                 # Event object that the current status is based on (used for STOPPED events)
        self.speedEstimate = None               # estimate of bus's current speed as float
        
    def updateSpeed(self):
        """update speed estimate based on last processed, previous, and next Timepoint"""
        if self.lastProcessedIndex > 1 and self.lastProcessedIndex <  len(self.bus.timepoints) - 1: # make sure there is a previous and next Timepoint
            tpPrevious= self.bus.timepoints[self.lastProcessedIndex - 1]
            tpNow = self.bus.timepoints[self.lastProcessedIndex]
            tpNext = self.bus.timepoints[self.lastProcessedIndex + 1]
            
            # compute new speed estimate by adding distances in miles between tpPrevious and tpNow and between tpNow and tpNext 
            # and dividing by difference between tpPrevious and tpNext
            combinedDistanceInMiles =   vincenty( (tpPrevious.lat, tpPrevious.lon), (tpNow.lat, tpNow.lon) ).miles \
                                      + vincenty( (tpNow.lat, tpNow.lon), (tpNext.lat, tpNext.lon) ).miles
            timeDifference = tpNext.time - tpPrevious.time
            self.speedEstimate = combinedDistanceInMiles * (3600 / timeDifference.total_seconds())
        else:                                                                               
            self.speedEstimate = None # couldn't calculate speed

class Observation():
    """represents an observation in the analysis process to be processed with the associated BusTracker""" 
    def __init__(self, busTracker, timepointIndex):
        self.busTracker = busTracker                                # BusTracker associated with this gps observation
        self.timepointIndex = timepointIndex                        # index of the timepoint of this gps observation in bus's Timepoint list
        self.timepoint = busTracker.bus.timepoints[timepointIndex]  # Timepoint for this gps observation (for convenience)

    def __lt__(self, observation):           
        """define < operator for two Observations by comparing datetime of their Timepoint objects (allows for storing Observations in priority queue)"""
        return self.timepoint.time < observation.timepoint.time

class Depot():
    """represents a bus depot or similar real world entity for defining "IN DEPOT" status and leaving/entering depot events"""
    def __init__(self, name, bbox):
        self.name = name   # name of the depot as string
        self.bbox = bbox   # bounding box for depot as 4-tuple (lat_bottom_left, lon_bottom_left, lan_top_right, lon_top_right) of floats
        
    def containsPoint(self, lat, lon):
        """test whether point with coordinates lat,lon is inside bounding box of this Depot object"""
        return lon > self.bbox[0] and lon < self.bbox[2] and lat > self.bbox[1] and lat < self.bbox[3]
    
    def inDepot(lat, lon, depots):  
        """test whether point with coordinate lat,lon is in any of the depots in provided list depots of Depot object. 
           Returns tuple of bool and Depot (if points is any Depot)."""
        for dep in depots:
            if dep.containsPoint(lat, lon):
                return (True, dep)
        return (False, None)
    
    def readFromCSV(fileName):
        """reads comma-separated text file with each row representing a depot and returns list of created Depot objects. 
           The order of columns in the file is expected to match the order of parameters and bounding box elements of the Depot class.""" 
        depots = []
        with open(os.path.join(os.path.dirname(__file__), fileName), "r") as depotFile:
            csvReader = csv.reader(depotFile, delimiter=',')
            for row in csvReader:                                                                       # go through rows in input file
                depots.append(Depot(row[0],(float(row[1]),float(row[2]),float(row[3]),float(row[4]))))  # add new Depot object for current row to Depot list
        return depots
                
