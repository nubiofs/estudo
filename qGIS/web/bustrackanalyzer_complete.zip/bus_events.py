# -*- coding: utf-8 -*-

import datetime
from geopy.distance import vincenty

from core_classes import Depot, BusTracker

class BusEvent():
    """abstract root class for deriving more specialized bus events from; each event has an associate Timepoint and each instantiable derived 
       class needs to provide an implementation of detect(...) and description()"""
    def __init__(self, timepoint):
        self.timepoint = timepoint  # Timepoint object for when and where this event happened
        
    def description(self):
        """returns a text description of the event suitable for storing in an attribute table"""
        pass  # abstract method that needs to be overwritten
        
    def detect(observation, depots, activeBusTrackers): 
        """process observation and checks whether this event occurs at the given observation. If yes, one or more instances of 
           this Event class are created and returned as a list"""
        pass  # abstract method that needs to be overwritten

class SingleBusEvent(BusEvent):
    """abstract class for all events that involve only a single bus and its properties"""
    def __init__(self, timepoint, bus):
        super(SingleBusEvent, self).__init__(timepoint) 
        self.bus = bus                                  # Bus object involved in this event
        
class BusStoppedEvent(SingleBusEvent):
    """represents an event where a bus hasn't move more than 3 meters for at least a minute"""
    def __init__(self, timepoint, bus, duration):
        super(BusStoppedEvent, self).__init__(timepoint, bus)
        self.duration = duration                               # duration how long the bus stopped 

    def detect(observation, depots, activeBusTrackers):
        """process observation and checks whether this event occurs at the given observation. If yes, one or more instances of 
           this Event class are created and returned as a list."""
        producedEvents = []                       # initialize list of newly created events to be returned by this function
        
        if observation.busTracker.status == BusTracker.STATUS_DRIVING:
            # look ahead until bus has moved at least 3 meters or the end of the Timepoint list is reached
            timeNotMoving = datetime.timedelta(seconds=0) # for keeping track of time the bus hasn't moved more than 3 meters
            distance = 0 # for keeping track of distance to original location 
            c = 1 # counter variable for looking ahead
            while distance < 3 and observation.timepointIndex  + c < len(observation.busTracker.bus.timepoints):  
                nextTimepoint =  observation.busTracker.bus.timepoints[observation.timepointIndex  + c] # next Timepoint while looking ahead
                distance = vincenty( (nextTimepoint.lat, nextTimepoint.lon), (observation.timepoint.lat, observation.timepoint.lon) ).m # distance to next Timepoint
            
                if distance < 3:  # if still below 3 meters, update timeNotMoving
                    timeNotMoving = nextTimepoint.time - observation.timepoint.time
                
                c += 1
    
            # check wehther bus didn't move for at least 60 seconds and if so generate event
            if timeNotMoving.total_seconds() >= 60:
                event =  BusStoppedEvent(observation.timepoint, observation.busTracker.bus, timeNotMoving)    # create stopped event
                producedEvents.append(event)                                                                  # add new event to result list
                observation.busTracker.status = BusTracker.STATUS_STOPPED                                                     # update BusTracker object to reflect detected stopped status
                observation.busTracker.statusEvent = event
                print("Event produced: ", str(event))

        else:
            pass # no stop event will be created while bus status is "IN DEPOT" or "DRIVING"
        
        return producedEvents

    def description(self):
        """returns a text description of the event suitable for storing in an attribute table"""
        return self.__str__()  # we directly use the string produced by __str__() but we could change this to a more compact description here
        
    def __str__(self):
        return "BusStoppedEvent: Bus {} stopped at {} for {} seconds".format(self.bus.busId, self.timepoint.time, self.duration.total_seconds() )
        
class MultipleBusesEvent(BusEvent):
    """abstract class for all events that involve more than a single bus"""  
    def __init__(self, timepoint, involvedBuses):
        super(MultipleBusesEvent, self).__init__(timepoint)
        self.involvedBuses = involvedBuses                  # list of Bus objects involved in this event
        
class BusEncounterEvent(MultipleBusesEvent):
    """represents an event in which two buses encountered each other with the distanace being less than 20m with both of them driving"""
    
    def detect(observation, depots, activeBusTrackers):
        """process observation and checks whether this event occurs at the given observation. If yes, one or more instances of 
           this Event class are created and returned as a list."""
        producedEvents = []   # initialize list of newly created events to be returned by this function
        
        if observation.busTracker.status == BusTracker.STATUS_DRIVING: 
            # go through all bus trackers and check distance between this and the other bus
            for otherTracker in activeBusTrackers:
                if otherTracker != observation.busTracker and otherTracker.status == BusTracker.STATUS_DRIVING and otherTracker.lastProcessedIndex >= 0:
                    otherBusTimepoint = otherTracker.bus.timepoints[otherTracker.lastProcessedIndex]
                    distance = vincenty( (observation.timepoint.lat, observation.timepoint.lon), (otherBusTimepoint.lat, otherBusTimepoint.lon) ).m
                    if distance < 20: # if distance is smaller than 20m, create event and add to result list
                         event = BusEncounterEvent(observation.timepoint, [ observation.busTracker.bus, otherTracker.bus ])
                         producedEvents.append(event)
                         print("Event produced: ", str(event))
              
        else:
            pass # no stop event will be created while bus status is "IN DEPOT" or "STOPPED"
                
        return producedEvents
    
    def description(self):
        """returns a text description of the event suitable for storing in an attribute table"""
        return self.__str__()  # we directly use the string produced by __str__() but we could change this to a more compact description here

    def __str__(self):
        return "BusEncounterEvent: Buses {}  at {}".format(' and '.join([bus.busId for bus in self.involvedBuses]), self.timepoint.time )
 

class BusDepotEvent(BusEvent):
    """abstract class for all events that involve only a single bus and a depot"""
    def __init__(self, timepoint, bus, depot):
        super(BusDepotEvent, self).__init__(timepoint)
        self.bus = bus        # Bus object involved in this event
        self.depot = depot    # Depot object involved in this event
        
class LeavingDepotEvent(BusDepotEvent):
    """represents the event that a bus left a depot"""
    
    def detect(observation, depots, activeBusTrackers):
        """process observation and checks whether this event occurs at the given observation. If yes, one or more instances of 
           this Event class are created and returned as a list."""
        producedEvents = [] # initialize list of newly created events to be returned by this function
        
        if observation.busTracker.status == BusTracker.STATUS_INDEPOT:
            isInDepot, depot = Depot.inDepot(observation.timepoint.lat, observation.timepoint.lon, depots)  # test whether bus is still in a depot
            if not isInDepot: # bus not in depot anymore, so leaving depot event will be created and added to result list
                event =  LeavingDepotEvent(observation.timepoint, observation.busTracker.bus, observation.busTracker.depot)
                producedEvents.append(event)
                observation.busTracker.status = BusTracker.STATUS_DRIVING  # update BusTracker object to reflect detected new status
                observation.busTracker.statusEvent = None  
                observation.busTracker.depot = None
                print("Event produced:", str(event))
        
        else:
            pass # nothing to do if bus is not in depot
        
        return producedEvents
    
    def description(self):
        """returns a text description of the event suitable for storing in an attribute table"""
        return self.__str__()  # we directly use the string produced by __str__() but we could change this to a more compact description here
    
    def __str__(self):
        return "LeavingDepotEvent: Bus {} left {} at {}".format(self.bus.busId, self.depot.name, self.timepoint.time )
   
class EnteringDepotEvent(BusDepotEvent):
    """represents the event that a bus left a depot"""
    
    def detect(observation, depots, activeBusTrackers):
        """process observation and checks whether this event occurs at the given observation. If yes, one or more instances of 
           this Event class are created and returned as a list."""
        producedEvents = []  # initialize list of newly created events to be returned by this function
        
        if observation.busTracker.status == BusTracker.STATUS_DRIVING:
            isInDepot, depot = Depot.inDepot(observation.timepoint.lat, observation.timepoint.lon, depots)
            if isInDepot: # bus is in depot now, so entering depot event will be created and added to result list
                event =  EnteringDepotEvent(observation.timepoint, observation.busTracker.bus, depot)
                producedEvents.append(event)
                observation.busTracker.status = BusTracker.STATUS_INDEPOT  # update BusTracker object to reflect detected new status
                observation.busTracker.depot = depot
                observation.busTracker.statusEvent = None
                print("Event produced:", str(event))
                
        else:
            pass # nothing to do if bus is "IN DEPOT" or "STOPPED"
                
        return producedEvents
    
    def description(self):
        """returns a text description of the event suitable for storing in an attribute table"""
        return self.__str__()  # we directly use the string produced by __str__() but we could change this to a more compact description here
 
    def __str__(self):
        return "EnteringDepotEvent: Bus {} entered {} at {}".format(self.bus.busId, self.depot.name, self.timepoint.time )
   