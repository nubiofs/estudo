# -*- coding: utf-8 -*-

import sys,os

from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QWidget, QGridLayout, QPushButton, QScrollArea, QApplication
import qgis

from core_classes import Depot, Bus
from bus_track_analyzer import BusTrackAnalyzer
from bus_tracker_widget import BusTrackerWidget
from bus_events import BusStoppedEvent, BusEncounterEvent, LeavingDepotEvent, EnteringDepotEvent

# set up input variables
busData = {} # dictionary of 
depots = []  # list of Depot objects for event detection
eventClasses = [ LeavingDepotEvent, EnteringDepotEvent, BusStoppedEvent, BusEncounterEvent ] # list of event classes to detect
depotFile = "dublin_depots.csv"                  # name of file with depot data
busFile = "dublin_bus_data.csv"  # name of file with bus gps data
busFileColumnIndices = { 'lon': 8, 'lat': 9, 'busId': 5, 'time': 0, 'line': 1 } # dictionary of column indices for required info
delay = 5  # delay in milliseconds between steps obervation processed during the analysis

# populate depot list and bus data dictionary with data read from input files
depotData = Depot.readFromCSV(depotFile)  
busData = Bus.readFromCSV(busFile, busFileColumnIndices) 

# create main BusTrackAnalyzer object
analyzer = BusTrackAnalyzer(busData, depotData, eventClasses)

class MainWidget(QWidget):
    """main window for this application containing a button to start the analysis and a scroll area for the BusTrackerWidget"""     
    def __init__(self, analyzer):
        super(MainWidget,self).__init__()
        self.resize(300,500)
        grid = QGridLayout(self)
        self.button = QPushButton("Run")
        grid.addWidget(self.button,0,0)
        self.busTrackerWidget = BusTrackerWidget(analyzer) # place BusTrackerWidget for our BusTrackAnalyzer in scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.busTrackerWidget)
        grid.addWidget(scroll, 1, 0)
        
        self.button.clicked.connect(run) # when button is clicked call run() function

def run():
    """performs only a single analysis step of the BusTrackAnalyzer but starts a timer after each step to call the function again after a
       brief delay until the analzzer has finished. Then saves events and bus tracks to GeoPackage output files."""
    mainWidget.button.setEnabled(False) # disable button so that it can't be run again
    if not analyzer.isFinished():       # if the analyzer hasn't finished yet, perform next step, update widget, and start timer 
                                        # to call this function again
        analyzer.nextStep()       
        mainWidget.busTrackerWidget.updateContent()  
        timer = QTimer()
        timer.singleShot(delay, run)
    else:                               # when the analyzer has finished write events and bus tracks to new GeoPackage files
        # initialize qgis
        qgis_prefix = os.getenv("QGIS_PREFIX_PATH")                # environment variable needs to be set correctly
        qgis.core.QgsApplication.setPrefixPath(qgis_prefix, True)
        qgis.core.QgsApplication.initQgis()
        
        print("writing")
        # write files
        analyzer.saveBusTrackPolylineFile("dublin_bus_tracks.gpkg", "GPKG")
        analyzer.saveEventPointFile("dublin_bus_events.gpkg",  "GPKG")

        # exit qgis
        qgis.core.QgsApplication.exitQgis()
        

# create main window and start event processing loop
app = QApplication(sys.argv)

mainWidget = MainWidget(analyzer) 
mainWidget.show()

sys.exit(app.exec_())
