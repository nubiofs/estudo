# -*- coding: utf-8 -*-

import heapq
import qgis

from bus_events import BusEvent
from core_classes import BusTracker, Observation, Depot

class BusTrackAnalyzer(): 
    """Perform step-by-step event analysis of bus track GPS data"""

    def __init__(self, busData, depotData, eventClasses): 
        self.allBusTrackers = []            # list of BusTracker objects for all buses currently being processed
        self.allEvents = []                 # used for storing all Event objects created during an analysis run
        self.lastProcessedTimepoint = None  # Timepoint of the last Observation that has been processed
        self._busData = busData             # dictionary mapping bus Id strings to Bus objects with GPS data
        self._depotData = depotData         # list of Depot objects used for Event detection
        self._observationQueue = []         # priority queue of next Observation objects to be processed for each bus 
        self._eventClasses = eventClasses   # list of instantiable subclasses of BusEvent that should be detected
        
        self.reset()   # initialize variables for new analysis run
    
    def reset(self):
        """reset current analysis run and reinitialize everything for a new run"""
        self.allBusTrackers = []
        self.allEvents = []
        self.lastProcessedTimepoint = None
        self._observationQueue = []
       
        for busId, bus in self._busData.items():  # go through all buses in the data
            busTracker = BusTracker(bus)          # create new BusTracker object for bus
        
            # set initial BusTracker status to "IN DEPOT" if bus is inside bounding box of one of the depots
            isInDepot, depot = Depot.inDepot(bus.timepoints[0].lat, bus.timepoints[0].lon, self._depotData)
            if isInDepot:
                busTracker.status = BusTracker.STATUS_INDEPOT
                busTracker.depot = depot
        
            self.allBusTrackers.append(busTracker) # add new BusTracker to list of all BusTrackers
            heapq.heappush(self._observationQueue, Observation(busTracker, 0)) # create Observation for first Timepoint of this bus 
                                                                               # and add to Observation priority queue
    
    def isFinished(self):
        """returns True if all Observations have been processed meaning the analysis run has finished, else False"""
        return not self._observationQueue
        
    def nextStep(self):
        """performs next step by processing Observation at the front of the Observations priority queue"""
        observation = heapq.heappop(self._observationQueue)           # get Observation that is at front of queue

        # go through list of BusEvent subclasses and invoke their detect() method; then collect the events produced
        # and add them to the allEvents lists
        for evClass in self._eventClasses:
            eventsProduced = evClass.detect(observation, self._depotData, self.allBusTrackers) # invoke event detection method
            self.allEvents.extend(eventsProduced)  # add resulting events to event list

        # update BusTracker of Observation that was just processed
        observation.busTracker.lastProcessedIndex += 1
        observation.busTracker.updateSpeed()

        if observation.busTracker.status == BusTracker.STATUS_STOPPED: # if  duration of a stopped event has just expired, change status to "DRIVING"
            if observation.timepoint.time > observation.busTracker.statusEvent.timepoint.time + observation.busTracker.statusEvent.duration:
                observation.busTracker.status = BusTracker.STATUS_DRIVING
                observation.busTracker.statusEvent = None
                
        # if this was not the last GPS Timepoint of this bus, create new Observation for the next point and add it to the Observation queue
        if observation.timepointIndex < len(observation.busTracker.bus.timepoints) - 1:  # not last point
            heapq.heappush(self._observationQueue, Observation(observation.busTracker, observation.timepointIndex + 1)  ) 

        # update analyzer status
        self.lastProcessedTimepoint = observation.timepoint

    def saveEventPointFile(self, filename, fileFormat):  
        """save event list as a WGS84 point vector dataset using qgis under the provided filename and using the given format. It is
           expected that qgis has been initalized before calling this method"""         
        # create layer for points in EPSG:4326 and with two string fields called TYPE and INFO
        layer = qgis.core.QgsVectorLayer('Point?crs=EPSG:4326&field=TYPE:string(50)&field=INFO:string(255)', 'events' , 'memory')
        prov = layer.dataProvider()

        # create point features for all events from self.allEvents and use their Event class name 
        # and string provided by description() method for the TYPE and INFO attribute columns
        features = []
        for event in self.allEvents: 
            p =  qgis.core.QgsPointXY(event.timepoint.lon, event.timepoint.lat)
            feat = qgis.core.QgsFeature()
            feat.setGeometry(qgis.core.QgsGeometry.fromPointXY(p))
            feat.setAttributes([type(event).__name__, event.description()])
            features.append(feat)
        
        # add features to layer and write layer to file
        prov.addFeatures(features) 
        qgis.core.QgsVectorFileWriter.writeAsVectorFormat( layer, filename, "utf-8", layer.crs(), fileFormat)
        
    def saveBusTrackPolylineFile(self, filename, fileFormat): 
        """save event list as a WGS84 point vector dataset using qgis under the provided filename and using the given format. It is
           expected that qgis has been initalized before calling this method""" 
        # create layer for polylines in EPSG:4326 and an integer field BUS_ID for storing the bus id for each track
        layer = qgis.core.QgsVectorLayer('LineString?crs=EPSG:4326&field=BUS_ID:integer', 'tracks' , 'memory')
        prov = layer.dataProvider()
        
        # create polyline features
        features = []
        for busId, bus in self._busData.items():
            # use list comprehension to produce list of QgsPoinXY objects from bus's Timepoints
            points = [ qgis.core.QgsPointXY(tp.lon,tp.lat) for tp in bus.timepoints ]
            feat = qgis.core.QgsFeature()
            lineGeometry = qgis.core.QgsGeometry.fromPolylineXY(points)
            feat.setGeometry(lineGeometry)
            feat.setAttributes([int(busId)])
            features.append(feat)
        
        # add features to layer and write layer to file
        prov.addFeatures(features)
        qgis.core.QgsVectorFileWriter.writeAsVectorFormat( layer, filename, "utf-8", layer.crs(), fileFormat)
       
