# -*- coding: utf-8 -*-

import os
from PyQt5 import QtGui, QtWidgets
from PyQt5.QtCore import Qt

from core_classes import BusTracker

class BusTrackerWidget(QtWidgets.QWidget):
    """widget derived from QWidget that illustrates current state of a BusTrackAnalyzer object by drawing status information for
       each involved bus"""
    def __init__(self, analyzer):
        super(BusTrackerWidget, self).__init__()  # calls QWidget's constructor first
        self.analyzer = analyzer                  # BusTrackAnalyzer object that this widget will depict information for
        self._busIcons = {                        # dictionary of icons to be used to depict bus status
                BusTracker.STATUS_DRIVING: QtGui.QPixmap(os.path.join(os.path.dirname(__file__), "status_driving.png")).scaledToHeight(15),
                BusTracker.STATUS_STOPPED: QtGui.QPixmap(os.path.join(os.path.dirname(__file__), "status_stopped.png")).scaledToHeight(15),
                BusTracker.STATUS_INDEPOT: QtGui.QPixmap(os.path.join(os.path.dirname(__file__), "status_indepot.png")).scaledToHeight(15) }
    
    def updateContent(self):
        """refreshes the content by creating a repaint event for this widget""" 
        self.repaint()  
    
    def paintEvent(self, event):
        """draws content with bus status information"""
        # set minimum dimensions basd on number of buses
        self.setMinimumHeight(len(self.analyzer.allBusTrackers) * 23 + 50)
        self.setMinimumWidth(425)
        
        # create QPainter and start drawing
        qp = QtGui.QPainter()
        qp.begin(self)
        
        normalFont = qp.font()
        boldFont = qp.font()
        boldFont.setBold(True)
        
        # draw time of last processed Timepoint at the top
        qp.setPen(Qt.darkGreen)
        qp.setFont(boldFont)
        if self.analyzer.lastProcessedTimepoint:
            qp.drawText(5,10,"Time: {0}".format(self.analyzer.lastProcessedTimepoint.time))
        qp.setPen(Qt.black)
        
        # loop through all BusTrackers in the BusTrackAnalyzer
        for index, tracker in enumerate(self.analyzer.allBusTrackers):
            
            # draw icon reflecting bus status
            qp.drawPixmap(5,20 + 23 * index, self._busIcons[tracker.status])
            
            # draw speed circles
            color = Qt.transparent
            if tracker.speedEstimate:
                if tracker.speedEstimate < 15: 
                    color = Qt.red
                elif tracker.speedEstimate < 25:
                    color = QtGui.QColor(244, 176, 66)
                elif tracker.speedEstimate < 40:
                    color = Qt.yellow
                else:
                    color = Qt.green
            qp.setBrush(color)
            qp.drawEllipse(80, 23 + 23 * index, 7, 7)
            
            # draw bus id and line text
            qp.setFont(boldFont)
            qp.drawText(100, 32 + 23 * index, tracker.bus.busId + "  [line "+tracker.bus.line+"]")
            
            # draw status and speed text
            qp.setFont(normalFont)
            statusText = "currently " + tracker.status
            if tracker.status == BusTracker.STATUS_INDEPOT:
                statusText += " " + tracker.depot.name
            elif tracker.status == BusTracker.STATUS_DRIVING:
                if not tracker.speedEstimate:
                    speedText = "???"
                else:
                    speedText  = "{0:.2f} mph".format(tracker.speedEstimate)
                statusText += " with " + speedText
            
            qp.drawText(200, 32 + 23 * index, statusText )
                   
        # done drawing    
        qp.end()
    