export interface LayerDetailItem {
  fontSet: string;
  fontIcon: string;
  text: string;
  disabled: boolean;
  type: 'transparency' | 'description' | 'legend';
}
