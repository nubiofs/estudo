import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mangol-legend',
  templateUrl: './legend.component.html',
  styleUrls: ['./legend.component.scss']
})
export class LegendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
