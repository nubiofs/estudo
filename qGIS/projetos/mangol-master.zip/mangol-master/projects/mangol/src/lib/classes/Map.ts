import Map from 'ol/Map';
export class MangolMap extends Map {
  constructor(options: any) {
    super(options);
  }
}
