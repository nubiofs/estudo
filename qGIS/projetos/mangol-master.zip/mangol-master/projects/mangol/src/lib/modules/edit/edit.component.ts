import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mangol-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.scss']
})
export class EditComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
