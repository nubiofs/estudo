export interface CursorMode {
  text?: string;
  cursor?: string;
  color?: [number, number, number, number];
  backgroundFill?: [number, number, number, number];
}
