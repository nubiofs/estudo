/*
 * Public API Surface of mangol
 */
export * from './lib/classes/Layer';
export * from './lib/classes/LayerGroup';
export * from './lib/mangol.service';
export * from './lib/mangol.component';
export * from './lib/mangol.module';
export * from './lib/interfaces/config.interface';
