export const code = `
import { Component } from '@angular/core';

@Component({
  selector: 'mangol-demo-map',
  template: '<mangol></mangol>'
})
export class DemoMapComponent {

}
`;
