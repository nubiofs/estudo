/**
 *
 */
package com.citigroup.gftp.spring.da.repository.support;

/**
 * @author ap16737
 *
 */
public interface EntityCollectionNameMapper {

	public String mapToCollectionName(Class<?> entityClass);

}
