package com.javasampleapproach.postgres.dao;

import com.javasampleapproach.postgres.model.Customer;

public interface CustomerDao {
	void insert(Customer cust);
}
