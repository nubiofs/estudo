package com.springjava4dev.postgres;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.javasampleapproach.postgres.ConfigurationMultiDatasourceApplication;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = ConfigurationMultiDatasourceApplication.class)
public class Configuration2datasourceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
