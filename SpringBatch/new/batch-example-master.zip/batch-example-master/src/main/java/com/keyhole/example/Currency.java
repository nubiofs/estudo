package com.keyhole.example;

public enum Currency {
	USD, GBP
}
