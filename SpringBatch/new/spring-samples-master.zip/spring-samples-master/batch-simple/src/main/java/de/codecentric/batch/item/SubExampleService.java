package de.codecentric.batch.item;


public class SubExampleService {
	
	public String echo(String echo){
		return echo;
	}

}
