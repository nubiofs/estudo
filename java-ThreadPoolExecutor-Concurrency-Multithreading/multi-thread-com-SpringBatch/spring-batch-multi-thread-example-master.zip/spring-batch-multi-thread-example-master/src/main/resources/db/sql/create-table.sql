CREATE TABLE Records (
id int PRIMARY KEY
);
