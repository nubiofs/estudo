package com.javasampleapproach.joblatebinding.tasklet;

public abstract class AbstracTasklet {
	protected String folder;
	protected String fileName;

	// GET & SET for folder member
	public String getFolder() {
		return folder;
	}

	public void setFolder(String folder) {
		this.folder = folder;
	}

	// GET & SET for fileName
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}