package com.javasampleapproach.joblatebinding.tasklet;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;

public class Tasklet2 extends AbstracTasklet implements Tasklet {

	Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	public Tasklet2(){
		log.info("Contruction - # Tasklet 2");
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		System.out.println("### Processing! Read content of File: " + fileName);
		
		// Build pathFile
		String pathFile = folder + "\\" + fileName;
		try (Stream<String> stream = Files.lines(Paths.get(pathFile))) {
			stream.forEach(System.out::println);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return RepeatStatus.FINISHED;
	}
}