package com.javasampleapproach.joblatebinding;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@EnableBatchProcessing
@ImportResource("classpath:batchjob.xml")
@SpringBootApplication
public class SpringBatchLateBindingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchLateBindingApplication.class, args);
	}
}