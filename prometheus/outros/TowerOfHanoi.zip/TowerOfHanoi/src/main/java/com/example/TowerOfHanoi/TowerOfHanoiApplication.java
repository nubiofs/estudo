package com.example.TowerOfHanoi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TowerOfHanoiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TowerOfHanoiApplication.class, args);
	}

}
